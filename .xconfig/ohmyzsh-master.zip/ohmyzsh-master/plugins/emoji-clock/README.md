# emoji-clock

The plugin displays current time as an emoji symbol with half hour accuracy.

To use it, add `emoji-clock` to the plugins array of your zshrc file:
```
plugins=(... emoji-clock)
```

## Features

| Function          | Description                                                          |
|-------------------|----------------------------------------------------------------------|
| `emoji-clock`     | Displays current time in clock emoji symbol with half hour accuracy  |
