# Cpanm

This plugin provides completion for [Cpanm](https://github.com/miyagawa/cpanminus) ([docs](https://metacpan.org/pod/App::cpanminus)).

To use it add cpanm to the plugins array in your zshrc file.

```zsh
plugins=(... cpanm)
```
